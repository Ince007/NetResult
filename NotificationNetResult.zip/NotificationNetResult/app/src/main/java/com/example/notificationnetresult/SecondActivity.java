package com.example.notificationnetresult;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Vincenzo Manno 10/05/2022
 */

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        TextView textView = findViewById(R.id.textLabel);
        Intent intent = getIntent();
        String titolo = intent.getExtras().getString("titolo");
        textView.setText(titolo);

    }

}
