package com.example.notificationnetresult;

import android.app.Application;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationManagerCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

/**
 * Vincenzo Manno 10/05/2022
 */

public class PushNotificationService extends FirebaseMessagingService {


    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onMessageReceived(@NonNull RemoteMessage message) {


        String titolo = message.getNotification().getTitle();
        String testo = message.getNotification().getBody();


        if(titolo.trim().equals("A"))
        {
            final String CHANNEL_ID = "HEADS_UP_NOTIFICATION";
            NotificationChannel canale = new NotificationChannel(
                    CHANNEL_ID,
                    "Heads Up Notification",
                    NotificationManager.IMPORTANCE_HIGH
            );

            getSystemService(NotificationManager.class).createNotificationChannel(canale);
            Notification.Builder notification = new Notification.Builder(this, CHANNEL_ID)
                    .setContentTitle(titolo)
                    .setContentText(testo)
                    .setSmallIcon(R.drawable.ic_launcher_background)
                    .setAutoCancel(true);
            NotificationManagerCompat.from(this).notify(1, notification.build());
        }

        else if (titolo.trim().equals("B"))
        {
            Log.i("PVL", "RECEIVED MESSAGE: " + titolo);
            Intent intent = new Intent(PushNotificationService.this, SecondActivity.class);
            intent.setAction("android.intent.action.MAIN");
            intent.addCategory("android.intent.category.LAUNCHER");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            intent.putExtra("titolo", titolo);
            startActivity(intent);
        }

        super.onMessageReceived(message);
    }


}
