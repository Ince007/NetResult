package com.example.notificationnetresult;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

/**
 * Vincenzo Manno 10/05/2022
 */

public class MainActivity extends AppCompatActivity {

    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.textLabell);


    }

    @Override
    protected void onResume() {

        if(getIntent() != null && getIntent().getExtras() != null) {
            String titolo = getIntent().getExtras().getString("netresult").trim();
            if (!titolo.equals("")) {
                if (titolo.equals("B")) {
                    textView.setText(titolo);
                }
            }
        }

        super.onResume();
    }
}